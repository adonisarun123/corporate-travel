import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  TrendingUp, 
  DollarSign, 
  Users, 
  Target, 
  CheckCircle, 
  Calendar,
  BarChart3,
  Plane,
  Building2,
  Smartphone,
  Shield,
  Globe,
  Zap
} from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
              <Plane className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-xl">TReBound</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#overview" className="text-muted-foreground hover:text-foreground transition-colors">Overview</a>
            <a href="#market" className="text-muted-foreground hover:text-foreground transition-colors">Market</a>
            <a href="#strategy" className="text-muted-foreground hover:text-foreground transition-colors">Strategy</a>
            <a href="#financials" className="text-muted-foreground hover:text-foreground transition-colors">Financials</a>
            <a href="#roadmap" className="text-muted-foreground hover:text-foreground transition-colors">Roadmap</a>
          </div>
          <Button size="sm">
            Get Started
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center overflow-hidden hero-gradient">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 py-20 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-white space-y-8">
              <div className="space-y-4">
                <Badge className="glass-card text-white border-white/20">
                  Corporate Travel Strategy 2025
                </Badge>
                <h1 className="text-5xl lg:text-7xl font-bold tracking-tight">
                  Revolutionize
                  <span className="block">Corporate Travel</span>
                </h1>
                <p className="text-xl text-white/90 max-w-lg">
                  Unlock the $728B market opportunity with TReBound's innovative hybrid business model. 
                  Technology-first approach delivering superior customer experiences.
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="glass-card p-4 rounded-xl">
                  <div className="text-2xl font-bold">$728B</div>
                  <div className="text-sm text-white/80">Market Size</div>
                </div>
                <div className="glass-card p-4 rounded-xl">
                  <div className="text-2xl font-bold">15.2%</div>
                  <div className="text-sm text-white/80">CAGR Growth</div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-orange-600 hover:bg-white/90">
                  View Strategy
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                  Download Report
                </Button>
              </div>
            </div>

            <div className="relative">
              <div className="glass-card p-8 rounded-2xl animate-float">
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center">
                      <CheckCircle className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-white">Market Entry Strategy</div>
                      <div className="text-sm text-white/70">Validated approach ready for execution</div>
                    </div>
                  </div>
                  <div className="bg-white/10 rounded-lg p-4">
                    <div className="text-sm text-white/80 mb-2">Revenue Projection</div>
                    <div className="text-3xl font-bold text-white">$23M</div>
                    <div className="text-sm text-green-400">Year 3 Target</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Takeaways Section */}
      <section id="overview" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Key Strategic Insights</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Comprehensive analysis reveals unprecedented opportunity in corporate travel management
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
                  <TrendingUp className="w-6 h-6 text-blue-600" />
                </div>
                <CardTitle>Market Opportunity</CardTitle>
                <CardDescription>$728B business travel segment growing at 15.2% CAGR</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Post-pandemic recovery at 85% levels
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Underserved SME segment opportunity
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Technology disruption creating gaps
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle>Investment & Returns</CardTitle>
                <CardDescription>$2.5M-$4M investment with 18-24 month payback</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    156% IRR over 5 years
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Break-even within 18 months
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Self-funded growth by Year 2
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-4">
                  <Target className="w-6 h-6 text-purple-600" />
                </div>
                <CardTitle>Strategic Approach</CardTitle>
                <CardDescription>Hybrid model: Services + Technology platform</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Immediate revenue from services
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Long-term platform scalability
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Risk-minimized market entry
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Market Analysis Section */}
      <section id="market" className="py-20 purple-gradient">
        <div className="container mx-auto px-4 text-white">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div>
                <Badge className="glass-card text-white border-white/20 mb-4">
                  Market Intelligence
                </Badge>
                <h2 className="text-4xl font-bold mb-6">
                  Massive Market Disruption Opportunity
                </h2>
                <p className="text-xl text-white/90">
                  Traditional players struggle with innovation while SME segment remains underserved. 
                  Perfect timing for technology-first market entry.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="glass-card p-6 rounded-xl">
                  <div className="text-3xl font-bold mb-2">$280B</div>
                  <div className="text-white/80">North America Market</div>
                </div>
                <div className="glass-card p-6 rounded-xl">
                  <div className="text-3xl font-bold mb-2">200%+</div>
                  <div className="text-white/80">TravelPerk Growth</div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Building2 className="w-5 h-5 text-yellow-400" />
                  <span>Enterprise: $400B (55% market share)</span>
                </div>
                <div className="flex items-center gap-3">
                  <Users className="w-5 h-5 text-yellow-400" />
                  <span>Mid-Market: $200B (27% market share)</span>
                </div>
                <div className="flex items-center gap-3">
                  <Smartphone className="w-5 h-5 text-yellow-400" />
                  <span>Small Business: $128B (18% market share)</span>
                </div>
              </div>
            </div>

            <div className="glass-card p-8 rounded-2xl">
              <h3 className="text-2xl font-bold mb-6">Competitive Landscape</h3>
              <div className="space-y-6">
                <div className="border-b border-white/20 pb-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="font-semibold">Concur SAP</div>
                      <div className="text-sm text-white/70">Enterprise dominance</div>
                    </div>
                    <Badge variant="outline" className="border-red-400 text-red-400">Vulnerable</Badge>
                  </div>
                  <div className="text-sm text-white/80">Complex, expensive, poor UX</div>
                </div>

                <div className="border-b border-white/20 pb-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="font-semibold">TravelPerk</div>
                      <div className="text-sm text-white/70">Technology leader</div>
                    </div>
                    <Badge variant="outline" className="border-green-400 text-green-400">Growing</Badge>
                  </div>
                  <div className="text-sm text-white/80">$150M+ ARR, 5K+ customers</div>
                </div>

                <div className="border-b border-white/20 pb-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="font-semibold">Expensify</div>
                      <div className="text-sm text-white/70">SME focused</div>
                    </div>
                    <Badge variant="outline" className="border-yellow-400 text-yellow-400">Limited</Badge>
                  </div>
                  <div className="text-sm text-white/80">Narrow expense focus only</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Financial Projections */}
      <section id="financials" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Financial Projections</h2>
            <p className="text-xl text-muted-foreground">
              Strong growth trajectory with multiple revenue streams
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Revenue Growth Trajectory
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-4 gap-4 text-center">
                    <div className="text-sm text-muted-foreground">Metric</div>
                    <div className="text-sm font-semibold">Year 1</div>
                    <div className="text-sm font-semibold">Year 2</div>
                    <div className="text-sm font-semibold">Year 3</div>
                  </div>
                  
                  <div className="grid grid-cols-4 gap-4 text-center py-3 bg-muted/50 rounded-lg">
                    <div className="text-sm font-medium">Revenue</div>
                    <div className="text-lg font-bold text-blue-600">$3.15M</div>
                    <div className="text-lg font-bold text-blue-600">$10.2M</div>
                    <div className="text-lg font-bold text-blue-600">$22.7M</div>
                  </div>

                  <div className="grid grid-cols-4 gap-4 text-center">
                    <div className="text-sm">Services</div>
                    <div className="text-sm">$2.6M</div>
                    <div className="text-sm">$6.2M</div>
                    <div className="text-sm">$10.7M</div>
                  </div>

                  <div className="grid grid-cols-4 gap-4 text-center">
                    <div className="text-sm">Platform</div>
                    <div className="text-sm">$0.55M</div>
                    <div className="text-sm">$4.0M</div>
                    <div className="text-sm">$12.0M</div>
                  </div>

                  <div className="grid grid-cols-4 gap-4 text-center py-3 bg-green-50 rounded-lg">
                    <div className="text-sm font-medium">Gross Margin</div>
                    <div className="text-sm">0%</div>
                    <div className="text-sm font-bold text-green-600">23.5%</div>
                    <div className="text-sm font-bold text-green-600">35.2%</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Investment & Returns
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-xl">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-600 mb-2">156%</div>
                      <div className="text-sm text-muted-foreground">Internal Rate of Return</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold mb-1">$4.15M</div>
                      <div className="text-xs text-muted-foreground">Total Investment</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold mb-1">18-24</div>
                      <div className="text-xs text-muted-foreground">Months to Break-even</div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <span className="text-sm">Customer LTV</span>
                      <span className="font-semibold">$75K - $125K</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <span className="text-sm">Customer CAC</span>
                      <span className="font-semibold">$5K - $8K</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                      <span className="text-sm">Churn Rate</span>
                      <span className="font-semibold text-green-600">&lt;5% annually</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Implementation Roadmap */}
      <section id="roadmap" className="py-20 cyan-gradient">
        <div className="container mx-auto px-4 text-white">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Implementation Roadmap</h2>
            <p className="text-xl text-white/90">
              Phased approach minimizing risk while maximizing opportunity
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="glass-card border-white/20">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-sm font-bold">1</div>
                  <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">Months 1-3</Badge>
                </div>
                <CardTitle className="text-white">Foundation Building</CardTitle>
                <CardDescription className="text-white/70">Market research and team setup</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm text-white/90">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Hire VP Sales & Marketing
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Complete market analysis
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Begin MVP development
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Establish partnerships
                  </li>
                </ul>
                <div className="mt-6 p-3 bg-white/10 rounded-lg">
                  <div className="text-xs text-white/70">Investment Required</div>
                  <div className="text-lg font-bold">$500K - $750K</div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-white/20">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-sm font-bold">2</div>
                  <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/30">Months 4-6</Badge>
                </div>
                <CardTitle className="text-white">Market Entry</CardTitle>
                <CardDescription className="text-white/70">Launch services and beta platform</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm text-white/90">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Launch consulting services
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Complete MVP platform
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Acquire first customers
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Validate product-market fit
                  </li>
                </ul>
                <div className="mt-6 p-3 bg-white/10 rounded-lg">
                  <div className="text-xs text-white/70">Investment Required</div>
                  <div className="text-lg font-bold">$1M - $1.5M</div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-white/20">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-sm font-bold">3</div>
                  <Badge className="bg-green-500/20 text-green-300 border-green-500/30">Months 7-12</Badge>
                </div>
                <CardTitle className="text-white">Scale & Growth</CardTitle>
                <CardDescription className="text-white/70">Full market launch and expansion</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm text-white/90">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Full platform launch
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Scale customer acquisition
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Expand team & operations
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    Achieve market leadership
                  </li>
                </ul>
                <div className="mt-6 p-3 bg-white/10 rounded-lg">
                  <div className="text-xs text-white/70">Investment Required</div>
                  <div className="text-lg font-bold">$1M - $1.75M</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Technology & Innovation */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Technology Excellence</h2>
            <p className="text-xl text-muted-foreground">
              Building competitive advantage through superior technology
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="border-0 shadow-lg text-center">
              <CardContent className="pt-8">
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Smartphone className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="font-semibold mb-2">Mobile-First Design</h3>
                <p className="text-sm text-muted-foreground">Consumer-grade experience with offline capabilities</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg text-center">
              <CardContent className="pt-8">
                <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="font-semibold mb-2">AI-Powered Automation</h3>
                <p className="text-sm text-muted-foreground">Intelligent booking recommendations and expense processing</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg text-center">
              <CardContent className="pt-8">
                <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Globe className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="font-semibold mb-2">Global Platform</h3>
                <p className="text-sm text-muted-foreground">Comprehensive supplier network and local compliance</p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg text-center">
              <CardContent className="pt-8">
                <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="font-semibold mb-2">Enterprise Security</h3>
                <p className="text-sm text-muted-foreground">SOC 2, GDPR compliance with enterprise-grade security</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 hero-gradient">
        <div className="container mx-auto px-4 text-center text-white">
          <div className="max-w-4xl mx-auto space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold">
              Ready to Transform Corporate Travel?
            </h2>
            <p className="text-xl text-white/90">
              The opportunity is significant, the timing is favorable, and TReBound has the capabilities to succeed. 
              Immediate action is recommended to capitalize on this strategic opportunity.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 my-12">
              <div className="glass-card p-6 rounded-xl">
                <div className="text-2xl font-bold mb-2">$23M</div>
                <div className="text-white/80">Year 3 Revenue Target</div>
              </div>
              <div className="glass-card p-6 rounded-xl">
                <div className="text-2xl font-bold mb-2">350+</div>
                <div className="text-white/80">Target Customers</div>
              </div>
              <div className="glass-card p-6 rounded-xl">
                <div className="text-2xl font-bold mb-2">18 mo</div>
                <div className="text-white/80">Break-even Timeline</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-orange-600 hover:bg-white/90">
                <Calendar className="w-4 h-4 mr-2" />
                Schedule Strategy Session
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                Download Full Report
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 bg-background border-t border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                  <Plane className="w-4 h-4 text-white" />
                </div>
                <span className="font-bold text-xl">TReBound</span>
              </div>
              <p className="text-muted-foreground">
                Revolutionizing corporate travel through innovative technology and superior customer experience.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Strategy</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#market" className="hover:text-foreground transition-colors">Market Analysis</a></li>
                <li><a href="#financials" className="hover:text-foreground transition-colors">Financial Projections</a></li>
                <li><a href="#roadmap" className="hover:text-foreground transition-colors">Implementation</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Full Report</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Executive Summary</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Financial Models</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>strategy@trebound.com</li>
                <li>+1 (555) 123-4567</li>
                <li>San Francisco, CA</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-border mt-12 pt-8 text-center text-muted-foreground">
            <p>&copy; 2025 TReBound. All rights reserved. Strategic business document prepared for executive review.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}